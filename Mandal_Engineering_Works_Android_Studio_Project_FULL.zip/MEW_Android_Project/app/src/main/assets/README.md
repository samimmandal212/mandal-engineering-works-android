# LedgerPOS — Installable App Package

## What's in this folder
- `index.html` — the app itself
- `manifest.webmanifest` — tells Android/Chrome this is an installable app. **All icons are embedded directly inside this file as base64 data** — not separate image files — so there is nothing for the browser to 404 on, no matter how you upload or host it.
- `sw.js` — service worker, makes the app work fully offline once installed
- `icons/` — the same icons as plain PNG files too, kept only as source files in case you want to swap in your own logo later (edit `manifest.webmanifest` and regenerate the base64 if so). They are **not required** for the app to work.

This is a genuine, spec-compliant **PWA (Progressive Web App)**. Once hosted online, Android Chrome offers a real "Install" button, the app gets its own home-screen icon, opens full-screen with no browser bar, shows in the recent-apps switcher, and works offline.

> **Fixed:** an earlier version referenced icon files at `icons/icon-192.png` etc. If that folder didn't get uploaded to your host (e.g. GitHub's web upload UI can silently drop nested folders), the browser reports `404 Not Found` for the icons and the "Install" check fails. That's now impossible — the icons live inside the manifest itself.

---

## Step 1 (required either way): Host these files online
A PWA has to be served over HTTPS. Free options:

- **GitHub Pages** — the most reliable way to preserve the folder structure is to **push via git** (not the drag-and-drop web uploader, which has dropped nested folders on some users before):
  ```
  git clone https://github.com/<you>/<repo>.git
  cd <repo>
  # copy index.html, manifest.webmanifest, sw.js, icons/ into this folder
  git add .
  git commit -m "Add LedgerPOS PWA"
  git push
  ```
  Then enable Pages in the repo's Settings → Pages. If you must use the web UI, upload the files one at a time and manually create the `icons` folder path when prompted — but since icons are now embedded in the manifest, you technically don't even need to upload the `icons/` folder at all for the app to install correctly.
- **Netlify Drop** (fastest) — app.netlify.com/drop, drag the whole folder in, done in seconds.
- **Vercel** or **Firebase Hosting** — similar drag-and-drop / CLI deploy.

Once hosted, open the URL on Android in Chrome — you'll see the "Install LedgerPOS" banner (or Chrome menu → **Install app**).

## Step 2 (optional): Get an actual `.apk`/`.aab`
Once you have a live HTTPS URL, use **pwabuilder.com** (free, no coding):
1. Paste your URL, click Start — it re-validates your manifest (the icon errors should be gone now)
2. **Package for stores → Android**
3. Download the `.apk` (direct install/sideload by anyone) and `.aab` (for Google Play Console, one-time $25 developer account)

## Alternative: native wrapper (Capacitor)
For deeper native features later (Bluetooth receipt printers, camera barcode scanning), wrap this with **Capacitor** — needs Node.js + Android Studio on your own computer. Happy to set that up when you're ready.

---

## Notes
- Every time you edit `index.html`, bump `CACHE_VERSION` at the top of `sw.js` (e.g. `ledgerpos-v3`) — otherwise phones that already installed the app keep serving the old cached version.
- All product/customer/bill data is stored locally on each user's device (`localStorage`) — there's no shared server, so every install has independent data.
- The manifest also now declares `id`, `categories`, `lang`, and `dir`, which PWABuilder flagged as missing/recommended. `screenshots` is still optional — it only improves the richness of the install prompt UI and isn't required to install; add it later if you want polished Play Store listing images.

---

## Team Login & Cloud Sync (optional, powered by your own free Firebase project)

By default the app runs exactly as before — one device, its own local data, optional PIN lock. If you want **real staff logins with roles** (admin/staff) and **automatic real-time sync** across every phone, connect your own Firebase project. It's free for a small shop's usage, and it's entirely your own project — nothing goes through any third party.

### 1. Create the Firebase project
1. Go to **console.firebase.google.com** → **Add project** → give it any name → finish the wizard (Google Analytics is optional, skip it).
2. In the left sidebar: **Build → Authentication** → **Get started** → enable the **Email/Password** sign-in method.
3. **Build → Firestore Database** → **Create database** → start in **production mode** → pick any region close to you.
4. Once created, go to **Firestore → Rules** and paste in the contents of `firestore.rules` (included in this package), then **Publish**.
5. Go to **Project settings** (gear icon, top left) → scroll to **Your apps** → click the **</>** (web) icon → register an app (any nickname) → it shows you a `firebaseConfig` object like:
   ```js
   { apiKey: "...", authDomain: "...", projectId: "...", storageBucket: "...", messagingSenderId: "...", appId: "..." }
   ```
   Copy that whole object.

### 2. Create the first admin account (one-time, done manually in the console)
This avoids any tricky "who's allowed to create the first admin" security-rule problem — you just do it once, directly:
1. **Authentication → Users → Add user** → enter your email + a password.
2. Copy the **User UID** it generates.
3. **Firestore Database → Start collection** → collection ID: `users` → **Document ID**: paste that UID → add three fields:
   - `email` (string) — the same email you used
   - `name` (string) — your name
   - `role` (string) — `admin`
4. Save.

### 3. Connect the app
1. Open the app → **Settings → Team Login & Cloud Sync** → paste the `firebaseConfig` object from step 1 → **Connect Cloud & Enable Login**.
2. The app reloads and shows a **Sign In** screen — sign in with the email/password from step 2.
3. You're now the admin. From **Settings → Manage Staff** you can add staff accounts (email + temporary password + role) directly from the app — no more manual console work needed for staff after this.
4. Repeat step 3 (just the "Connect Cloud" part, pasting the same config) on every other phone that should share this shop's data — each person signs in with their own account.

### What syncs and what doesn't
- Once connected, all products, customers, bills, payments, categories, and settings sync in real time across every signed-in device.
- **Roles:** admins get full access; staff can sell (POS), view inventory/customers/bills, and record payments, but can't edit products/categories, change settings, or manage staff — those are hidden/blocked for them in the app.
- Note: because everything syncs as one combined document (to keep the app simple), the security rules can't restrict staff from editing specific fields at the database level — that boundary is enforced by the app's UI. This is fine for a small trusted team; if you later need it airtight against a technically savvy staff member editing things via browser dev tools, that would need splitting the data into per-collection documents with field-level rules — happy to help with that if you need it.
- To fully revoke someone's access, remove them in **Settings → Manage Staff** (blocks them immediately) — for a complete cleanup, also delete their account in Firebase Console → Authentication.
- **Disconnect Cloud** in Settings switches a device back to fully offline/local mode at any time.




## Unit Manager Update
Inventory products now support editable units (Piece, Set, Pair, Box, Dozen, Kilogram, Gram, Litre, Meter, Foot) plus custom units. Use the 📏 Units button in Inventory to add, rename, or delete units. Product prices and stock quantities display their unit.
