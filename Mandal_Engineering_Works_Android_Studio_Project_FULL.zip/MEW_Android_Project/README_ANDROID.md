# Mandal Engineering Works POS — Android APK Project

This project wraps the supplied `appv5` web POS in a native Android WebView.

## Build
1. Install Android Studio (latest stable).
2. Open this folder: `MEW_Android_Project`.
3. Let Gradle sync and install Android SDK Platform 35 if Android Studio asks.
4. Build > Build APK(s).
5. The debug APK will be under `app/build/outputs/apk/debug/`.

## Important
- The app keeps the existing POS HTML/JS and its LocalStorage database.
- Internet permission is enabled because the supplied app loads jsPDF/pdf.js from CDN.
- Microphone permission is included for browser voice features.
- Android file chooser support is included for PDF/image uploads and restore files.
- DownloadManager support is included for normal browser downloads.

For a Play Store release, create a signed release build with a secure keystore.
